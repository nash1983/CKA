##### configmap
* Complete ConfigMap docs: https://kubernetes.io/docs/tasks/configure-pod-container/configure-pod-configmap/

##### secret
* Complete Secret docs: https://kubernetes.io/docs/tasks/inject-data-application/distribute-credentials-secure/
